﻿using System;

class Program
{
    static void CountPositiveNegative(int[] arr)
    {
        int positive = 0, negative = 0;
        foreach (int num in arr)
        {
            if (num > 0) positive++;
            else if (num < 0) negative++;
        }
        Console.WriteLine($"So luong so duong: {positive}");
        Console.WriteLine($"So luong so am: {negative}");
    }

    static void Main()
    {
        Console.Write("Nhap so phan tu mang: ");
        int n = int.Parse(Console.ReadLine());

        int[] arr = new int[n];
        Console.WriteLine($"Nhap {n} phan tu:");
        for (int i = 0; i < n; i++)
        {
            arr[i] = int.Parse(Console.ReadLine());
        }

        CountPositiveNegative(arr);
    }
}