﻿using System;

class Program
{
    static int TimSoLonThuHai(int[] arr)
    {
        if (arr.Length < 2)
        {
            throw new ArgumentException("Mang phai co it nhat hai phan tu.");
        }

        int max = int.MinValue;
        int secondMax = int.MinValue;

        foreach (int so in arr)
        {
            if (so > max)
            {
                secondMax = max;
                max = so;
            }
            else if (so > secondMax && so != max)
            {
                secondMax = so;
            }
        }

        return secondMax;
    }

    static void Main()
    {
        int[] mang = { 12, 35, 1, 10, 34, 1 };

        try
        {
            int soLonThuHai = TimSoLonThuHai(mang);
            Console.WriteLine("So lon thu hai trong mang la: " + soLonThuHai);
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
}
