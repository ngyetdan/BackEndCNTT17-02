﻿using System;

class Program
{
    static void SortArrayAscending(double[] arr)
    {
        Array.Sort(arr);
    }

    static void Main()
    {
        Console.Write("Nhap so phan tu mang: ");
        int n = int.Parse(Console.ReadLine());

        double[] arr = new double[n];
        Console.WriteLine($"Nhap {n} phan tu:");
        for (int i = 0; i < n; i++)
        {
            arr[i] = double.Parse(Console.ReadLine());
        }

        SortArrayAscending(arr);
        Console.WriteLine("Mang sau khi sap xep tang dan:");
        foreach (double num in arr)
        {
            Console.Write($"{num} ");
        }
    }
}