﻿using System;
using System.Collections.Generic;

// Lop Nguoi quan ly thong tin ca nhan
class Nguoi
{
    protected string hoTen;
    protected int namSinh;
    protected string queQuan;
    protected string soCMND;

    public Nguoi() { }
    public Nguoi(string hoTen, int namSinh, string queQuan, string soCMND)
    {
        this.hoTen = hoTen;
        this.namSinh = namSinh;
        this.queQuan = queQuan;
        this.soCMND = soCMND;
    }

    public virtual void Nhap()
    {
        Console.Write("Nhap ho ten: ");
        hoTen = Console.ReadLine();
        Console.Write("Nhap nam sinh: ");
        namSinh = int.Parse(Console.ReadLine());
        Console.Write("Nhap que quan: ");
        queQuan = Console.ReadLine();
        Console.Write("Nhap so CMND: ");
        soCMND = Console.ReadLine();
    }

    public virtual void HienThi()
    {
        Console.WriteLine($"Ho ten: {hoTen}, Nam sinh: {namSinh}, Que quan: {queQuan}, So CMND: {soCMND}");
    }

    public string LayQueQuan()
    {
        return queQuan;
    }
}

// Lop CBGV ke thua tu Nguoi
class CBGV : Nguoi
{
    private double luongCung;
    private double thuong;
    private double phat;
    private double luongThucLinh;

    public CBGV() : base() { }
    public CBGV(string hoTen, int namSinh, string queQuan, string soCMND, double luongCung, double thuong, double phat)
        : base(hoTen, namSinh, queQuan, soCMND)
    {
        this.luongCung = luongCung;
        this.thuong = thuong;
        this.phat = phat;
        TinhLuongThucLinh();
    }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap luong cung: ");
        luongCung = double.Parse(Console.ReadLine());
        Console.Write("Nhap thuong: ");
        thuong = double.Parse(Console.ReadLine());
        Console.Write("Nhap phat: ");
        phat = double.Parse(Console.ReadLine());
        TinhLuongThucLinh();
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Luong cung: {luongCung}, Thuong: {thuong}, Phat: {phat}, Luong thuc linh: {luongThucLinh}");
    }

    public void TinhLuongThucLinh()
    {
        luongThucLinh = luongCung + thuong - phat;
    }

    public double LayLuongThucLinh()
    {
        return luongThucLinh;
    }
}

// Lop quan ly danh sach CBGV
class QuanLyCBGV
{
    private List<CBGV> danhSachCBGV = new List<CBGV>();

    public void NhapDanhSach()
    {
        Console.Write("Nhap so luong can bo giao vien: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhap thong tin CBGV thu {i + 1}:");
            CBGV cbgv = new CBGV();
            cbgv.Nhap();
            danhSachCBGV.Add(cbgv);
        }
    }

    public void TimKiemTheoQueQuan()
    {
        Console.Write("Nhap que quan can tim: ");
        string queQuan = Console.ReadLine();
        bool timThay = false;

        foreach (var cbgv in danhSachCBGV)
        {
            if (cbgv.LayQueQuan().Equals(queQuan, StringComparison.OrdinalIgnoreCase))
            {
                cbgv.HienThi();
                timThay = true;
            }
        }

        if (!timThay)
        {
            Console.WriteLine("Khong tim thay CBGV co que quan: " + queQuan);
        }
    }

    public void HienThiLuongTren5Trieu()
    {
        bool timThay = false;
        foreach (var cbgv in danhSachCBGV)
        {
            if (cbgv.LayLuongThucLinh() > 5000000)
            {
                cbgv.HienThi();
                timThay = true;
            }
        }

        if (!timThay)
        {
            Console.WriteLine("Khong co CBGV co luong thuc linh tren 5 trieu!");
        }
    }

    public void ChayChuongTrinh()
    {
        while (true)
        {
            Console.WriteLine("\n1. Nhap danh sach CBGV");
            Console.WriteLine("2. Tim kiem theo que quan");
            Console.WriteLine("3. Hien thi CBGV co luong tren 5 trieu");
            Console.WriteLine("4. Thoat");
            Console.Write("Nhap lua chon: ");
            int luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    NhapDanhSach();
                    break;
                case 2:
                    TimKiemTheoQueQuan();
                    break;
                case 3:
                    HienThiLuongTren5Trieu();
                    break;
                case 4:
                    return;
                default:
                    Console.WriteLine("Lua chon khong hop le!");
                    break;
            }
        }
    }
}

// Chuong trinh chinh
class Program
{
    static void Main(string[] args)
    {
        QuanLyCBGV quanLy = new QuanLyCBGV();
        quanLy.ChayChuongTrinh();
    }
}