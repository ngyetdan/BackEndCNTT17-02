﻿using System;
using System.Collections.Generic;

// Lop DaGiac
class DaGiac
{
    protected int soCanh;
    protected int[] kichThuocCanh;

    public DaGiac() { }
    public DaGiac(int soCanh)
    {
        this.soCanh = soCanh;
        kichThuocCanh = new int[soCanh];
    }

    public virtual void Nhap()
    {
        Console.Write("Nhap so canh: ");
        soCanh = int.Parse(Console.ReadLine());
        kichThuocCanh = new int[soCanh];
        for (int i = 0; i < soCanh; i++)
        {
            Console.Write($"Nhap do dai canh thu {i + 1}: ");
            kichThuocCanh[i] = int.Parse(Console.ReadLine());
        }
    }

    public virtual int TinhChuVi()
    {
        int chuVi = 0;
        foreach (int canh in kichThuocCanh)
        {
            chuVi += canh;
        }
        return chuVi;
    }

    public void InCacCanh()
    {
        Console.Write("Cac canh: ");
        foreach (int canh in kichThuocCanh)
        {
            Console.Write($"{canh} ");
        }
        Console.WriteLine();
    }

    public int[] LayCacCanh()
    {
        return kichThuocCanh;
    }
}

// Lop TamGiac ke thua tu DaGiac
class TamGiac : DaGiac
{
    public TamGiac() : base(3) { }

    public override void Nhap()
    {
        soCanh = 3;
        kichThuocCanh = new int[soCanh];
        for (int i = 0; i < soCanh; i++)
        {
            Console.Write($"Nhap do dai canh thu {i + 1}: ");
            kichThuocCanh[i] = int.Parse(Console.ReadLine());
        }
    }

    public override int TinhChuVi()
    {
        return base.TinhChuVi();
    }

    public double TinhDienTich()
    {
        double p = TinhChuVi() / 2.0;
        double a = kichThuocCanh[0], b = kichThuocCanh[1], c = kichThuocCanh[2];
        return Math.Sqrt(p * (p - a) * (p - b) * (p - c));
    }

    public bool LaTamGiacPitago()
    {
        int a = kichThuocCanh[0], b = kichThuocCanh[1], c = kichThuocCanh[2];
        int[] canh = new int[] { a, b, c };
        Array.Sort(canh);
        return canh[0] * canh[0] + canh[1] * canh[1] == canh[2] * canh[2];
    }
}

// Chuong trinh chinh
class Program
{
    static void Main(string[] args)
    {
        List<TamGiac> danhSachTamGiac = new List<TamGiac>();

        Console.Write("Nhap so luong tam giac: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhap thong tin tam giac thu {i + 1}:");
            TamGiac tamGiac = new TamGiac();
            tamGiac.Nhap();
            danhSachTamGiac.Add(tamGiac);
        }

        Console.WriteLine("\nCac tam giac thoa man dinh ly Pitago:");
        bool timThay = false;
        foreach (var tamGiac in danhSachTamGiac)
        {
            if (tamGiac.LaTamGiacPitago())
            {
                tamGiac.InCacCanh();
                timThay = true;
            }
        }

        if (!timThay)
        {
            Console.WriteLine("Khong co tam giac nao thoa man dinh ly Pitago!");
        }
    }
}