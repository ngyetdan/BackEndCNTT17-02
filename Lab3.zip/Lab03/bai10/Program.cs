﻿using System;
using System.Text.RegularExpressions;

// Lop VanBan
class VanBan
{
    private string xau;

    public VanBan()
    {
        xau = "";
    }

    public VanBan(string st)
    {
        xau = st;
    }

    public void Nhap()
    {
        Console.Write("Nhap xau ky tu: ");
        xau = Console.ReadLine();
    }

    public int DemSoTu()
    {
        if (string.IsNullOrWhiteSpace(xau)) return 0;
        string[] tu = xau.Trim().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        return tu.Length;
    }

    public int DemKyTuH()
    {
        int dem = 0;
        foreach (char c in xau.ToLower())
        {
            if (c == 'h') dem++;
        }
        return dem;
    }

    public void ChuanHoa()
    {
        xau = Regex.Replace(xau.Trim(), @"\s+", " ");
    }

    public void HienThi()
    {
        Console.WriteLine($"Xau: {xau}");
    }

    public void ChayChuongTrinh()
    {
        Nhap();
        while (true)
        {
            Console.WriteLine("\n1. Dem so tu");
            Console.WriteLine("2. Dem so ky tu H");
            Console.WriteLine("3. Chuan hoa xau");
            Console.WriteLine("4. Thoat");
            Console.Write("Nhap lua chon: ");
            int luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    Console.WriteLine($"So tu: {DemSoTu()}");
                    break;
                case 2:
                    Console.WriteLine($"So ky tu H: {DemKyTuH()}");
                    break;
                case 3:
                    ChuanHoa();
                    Console.WriteLine("Xau sau khi chuan hoa:");
                    HienThi();
                    break;
                case 4:
                    return;
                default:
                    Console.WriteLine("Lua chon khong hop le!");
                    break;
            }
        }
    }
}

// Chuong trinh chinh
class Program
{
    static void Main(string[] args)
    {
        VanBan vanBan = new VanBan();
        vanBan.ChayChuongTrinh();
    }
}