﻿using System;
using System.Collections.Generic;

// Lop cha ThiSinh
class ThiSinh
{
    protected string soBaoDanh;
    protected string hoTen;
    protected string diaChi;
    protected int uuTien;

    public ThiSinh() { }
    public ThiSinh(string soBaoDanh, string hoTen, string diaChi, int uuTien)
    {
        this.soBaoDanh = soBaoDanh;
        this.hoTen = hoTen;
        this.diaChi = diaChi;
        this.uuTien = uuTien;
    }

    public virtual void Nhap()
    {
        Console.Write("Nhap so bao danh: ");
        soBaoDanh = Console.ReadLine();
        Console.Write("Nhap ho ten: ");
        hoTen = Console.ReadLine();
        Console.Write("Nhap dia chi: ");
        diaChi = Console.ReadLine();
        Console.Write("Nhap muc uu tien: ");
        uuTien = int.Parse(Console.ReadLine());
    }

    public virtual void HienThi()
    {
        Console.WriteLine($"So bao danh: {soBaoDanh}, Ho ten: {hoTen}, Dia chi: {diaChi}, Uu tien: {uuTien}");
    }

    public virtual double TinhTongDiem()
    {
        return 0;
    }

    public string LaySoBaoDanh()
    {
        return soBaoDanh;
    }

    public virtual string LayKhoiThi()
    {
        return "";
    }
}

// Lop ThiSinhKhoiA ke thua tu ThiSinh
class ThiSinhKhoiA : ThiSinh
{
    private double diemToan, diemLy, diemHoa;

    public ThiSinhKhoiA() : base() { }
    public ThiSinhKhoiA(string soBaoDanh, string hoTen, string diaChi, int uuTien, double diemToan, double diemLy, double diemHoa)
        : base(soBaoDanh, hoTen, diaChi, uuTien)
    {
        this.diemToan = diemToan;
        this.diemLy = diemLy;
        this.diemHoa = diemHoa;
    }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap diem Toan: ");
        diemToan = double.Parse(Console.ReadLine());
        Console.Write("Nhap diem Ly: ");
        diemLy = double.Parse(Console.ReadLine());
        Console.Write("Nhap diem Hoa: ");
        diemHoa = double.Parse(Console.ReadLine());
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Diem Toan: {diemToan}, Diem Ly: {diemLy}, Diem Hoa: {diemHoa}, Tong diem: {TinhTongDiem()}");
    }

    public override double TinhTongDiem()
    {
        return diemToan + diemLy + diemHoa + uuTien;
    }

    public override string LayKhoiThi()
    {
        return "KhoiA";
    }
}

// Lop ThiSinhKhoiB ke thua tu ThiSinh
class ThiSinhKhoiB : ThiSinh
{
    private double diemToan, diemHoa, diemSinh;

    public ThiSinhKhoiB() : base() { }
    public ThiSinhKhoiB(string soBaoDanh, string hoTen, string diaChi, int uuTien, double diemToan, double diemHoa, double diemSinh)
        : base(soBaoDanh, hoTen, diaChi, uuTien)
    {
        this.diemToan = diemToan;
        this.diemHoa = diemHoa;
        this.diemSinh = diemSinh;
    }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap diem Toan: ");
        diemToan = double.Parse(Console.ReadLine());
        Console.Write("Nhap diem Hoa: ");
        diemHoa = double.Parse(Console.ReadLine());
        Console.Write("Nhap diem Sinh: ");
        diemSinh = double.Parse(Console.ReadLine());
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Diem Toan: {diemToan}, Diem Hoa: {diemHoa}, Diem Sinh: {diemSinh}, Tong diem: {TinhTongDiem()}");
    }

    public override double TinhTongDiem()
    {
        return diemToan + diemHoa + diemSinh + uuTien;
    }

    public override string LayKhoiThi()
    {
        return "KhoiB";
    }
}

// Lop ThiSinhKhoiC ke thua tu ThiSinh
class ThiSinhKhoiC : ThiSinh
{
    private double diemVan, diemSu, diemDia;

    public ThiSinhKhoiC() : base() { }
    public ThiSinhKhoiC(string soBaoDanh, string hoTen, string diaChi, int uuTien, double diemVan, double diemSu, double diemDia)
        : base(soBaoDanh, hoTen, diaChi, uuTien)
    {
        this.diemVan = diemVan;
        this.diemSu = diemSu;
        this.diemDia = diemDia;
    }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap diem Van: ");
        diemVan = double.Parse(Console.ReadLine());
        Console.Write("Nhap diem Su: ");
        diemSu = double.Parse(Console.ReadLine());
        Console.Write("Nhap diem Dia: ");
        diemDia = double.Parse(Console.ReadLine());
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Diem Van: {diemVan}, Diem Su: {diemSu}, Diem Dia: {diemDia}, Tong diem: {TinhTongDiem()}");
    }

    public override double TinhTongDiem()
    {
        return diemVan + diemSu + diemDia + uuTien;
    }

    public override string LayKhoiThi()
    {
        return "KhoiC";
    }
}

// Lop TuyenSinh quan ly danh sach thi sinh
class TuyenSinh
{
    private List<ThiSinh> danhSachThiSinh = new List<ThiSinh>();

    public void NhapThongTin()
    {
        Console.WriteLine("Ban muon nhap thong tin cho: 1. Khoi A, 2. Khoi B, 3. Khoi C");
        int luaChon = int.Parse(Console.ReadLine());

        ThiSinh thiSinh = null;
        switch (luaChon)
        {
            case 1:
                thiSinh = new ThiSinhKhoiA();
                break;
            case 2:
                thiSinh = new ThiSinhKhoiB();
                break;
            case 3:
                thiSinh = new ThiSinhKhoiC();
                break;
            default:
                Console.WriteLine("Lua chon khong hop le!");
                return;
        }

        thiSinh.Nhap();
        danhSachThiSinh.Add(thiSinh);
    }

    public void HienThiThiSinhTrungTuyen()
    {
        double diemChuanKhoiA = 15;
        double diemChuanKhoiB = 16;
        double diemChuanKhoiC = 13.5;
        bool coThiSinhTrungTuyen = false;

        foreach (var thiSinh in danhSachThiSinh)
        {
            double tongDiem = thiSinh.TinhTongDiem();
            string khoiThi = thiSinh.LayKhoiThi();
            bool trungTuyen = false;

            if (khoiThi == "KhoiA" && tongDiem >= diemChuanKhoiA)
            {
                trungTuyen = true;
            }
            else if (khoiThi == "KhoiB" && tongDiem >= diemChuanKhoiB)
            {
                trungTuyen = true;
            }
            else if (khoiThi == "KhoiC" && tongDiem >= diemChuanKhoiC)
            {
                trungTuyen = true;
            }

            if (trungTuyen)
            {
                thiSinh.HienThi();
                Console.WriteLine("-----------------");
                coThiSinhTrungTuyen = true;
            }
        }

        if (!coThiSinhTrungTuyen)
        {
            Console.WriteLine("Khong co thi sinh trung tuyen!");
        }
    }

    public void TimKiemTheoSoBaoDanh()
    {
        Console.Write("Nhap so bao danh can tim: ");
        string soBaoDanh = Console.ReadLine();
        bool timThay = false;

        foreach (var thiSinh in danhSachThiSinh)
        {
            if (thiSinh.LaySoBaoDanh().Equals(soBaoDanh))
            {
                thiSinh.HienThi();
                timThay = true;
                break;
            }
        }

        if (!timThay)
        {
            Console.WriteLine("Khong tim thay thi sinh co so bao danh: " + soBaoDanh);
        }
    }

    public void ChayChuongTrinh()
    {
        while (true)
        {
            Console.WriteLine("\n1. Nhap thong tin thi sinh");
            Console.WriteLine("2. Hien thi thi sinh trung tuyen");
            Console.WriteLine("3. Tim kiem theo so bao danh");
            Console.WriteLine("4. Thoat");
            Console.Write("Nhap lua chon: ");
            int luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    NhapThongTin();
                    break;
                case 2:
                    HienThiThiSinhTrungTuyen();
                    break;
                case 3:
                    TimKiemTheoSoBaoDanh();
                    break;
                case 4:
                    return;
                default:
                    Console.WriteLine("Lua chon khong hop le!");
                    break;
            }
        }
    }
}

// Chuong trinh chinh
class Program
{
    static void Main(string[] args)
    {
        TuyenSinh tuyenSinh = new TuyenSinh();
        tuyenSinh.ChayChuongTrinh();
    }
}