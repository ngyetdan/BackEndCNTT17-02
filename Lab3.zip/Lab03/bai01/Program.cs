﻿using System;
using System.Collections.Generic;

// Lop cha CanBo
class CanBo
{
    protected string hoTen;
    protected int namSinh;
    protected string gioiTinh;
    protected string diaChi;

    public CanBo() { }
    public CanBo(string hoTen, int namSinh, string gioiTinh, string diaChi)
    {
        this.hoTen = hoTen;
        this.namSinh = namSinh;
        this.gioiTinh = gioiTinh;
        this.diaChi = diaChi;
    }

    public virtual void Nhap()
    {
        Console.Write("Nhap ho ten: ");
        hoTen = Console.ReadLine();
        Console.Write("Nhap nam sinh: ");
        namSinh = int.Parse(Console.ReadLine());
        Console.Write("Nhap gioi tinh: ");
        gioiTinh = Console.ReadLine();
        Console.Write("Nhap dia chi: ");
        diaChi = Console.ReadLine();
    }

    public virtual void HienThi()
    {
        Console.WriteLine($"Ho ten: {hoTen}, Nam sinh: {namSinh}, Gioi tinh: {gioiTinh}, Dia chi: {diaChi}");
    }

    public string LayHoTen()
    {
        return hoTen;
    }
}

// Lop CongNhan ke thua tu CanBo
class CongNhan : CanBo
{
    private string bac;

    public CongNhan() : base() { }
    public CongNhan(string hoTen, int namSinh, string gioiTinh, string diaChi, string bac)
        : base(hoTen, namSinh, gioiTinh, diaChi)
    {
        this.bac = bac;
    }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap bac (vi du: 3/7): ");
        bac = Console.ReadLine();
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Bac: {bac}");
    }
}

// Lop KySu ke thua tu CanBo
class KySu : CanBo
{
    private string nganhDaoTao;

    public KySu() : base() { }
    public KySu(string hoTen, int namSinh, string gioiTinh, string diaChi, string nganhDaoTao)
        : base(hoTen, namSinh, gioiTinh, diaChi)
    {
        this.nganhDaoTao = nganhDaoTao;
    }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap nganh dao tao: ");
        nganhDaoTao = Console.ReadLine();
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Nganh dao tao: {nganhDaoTao}");
    }
}

// Lop NhanVien ke thua tu CanBo
class NhanVien : CanBo
{
    private string congViec;

    public NhanVien() : base() { }
    public NhanVien(string hoTen, int namSinh, string gioiTinh, string diaChi, string congViec)
        : base(hoTen, namSinh, gioiTinh, diaChi)
    {
        this.congViec = congViec;
    }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap cong viec: ");
        congViec = Console.ReadLine();
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Cong viec: {congViec}");
    }
}

// Lop QLCB quan ly danh sach can bo
class QLCB
{
    private List<CanBo> danhSachCanBo = new List<CanBo>();

    public void NhapThongTin()
    {
        Console.WriteLine("Ban muon nhap thong tin cho: 1. Cong nhan, 2. Ky su, 3. Nhan vien");
        int luaChon = int.Parse(Console.ReadLine());

        CanBo canBo = null;
        switch (luaChon)
        {
            case 1:
                canBo = new CongNhan();
                break;
            case 2:
                canBo = new KySu();
                break;
            case 3:
                canBo = new NhanVien();
                break;
            default:
                Console.WriteLine("Lua chon khong hop le!");
                return;
        }

        canBo.Nhap();
        danhSachCanBo.Add(canBo);
    }

    public void TimKiemTheoHoTen()
    {
        Console.Write("Nhap ho ten can tim: ");
        string hoTen = Console.ReadLine();
        bool timThay = false;

        foreach (var canBo in danhSachCanBo)
        {
            if (canBo.LayHoTen().Equals(hoTen, StringComparison.OrdinalIgnoreCase))
            {
                canBo.HienThi();
                timThay = true;
            }
        }

        if (!timThay)
        {
            Console.WriteLine("Khong tim thay can bo co ho ten: " + hoTen);
        }
    }

    public void HienThiDanhSach()
    {
        if (danhSachCanBo.Count == 0)
        {
            Console.WriteLine("Danh sach trong!");
            return;
        }

        foreach (var canBo in danhSachCanBo)
        {
            canBo.HienThi();
            Console.WriteLine("-----------------");
        }
    }

    public void ChayChuongTrinh()
    {
        while (true)
        {
            Console.WriteLine("\n1. Nhap thong tin can bo");
            Console.WriteLine("2. Tim kiem theo ho ten");
            Console.WriteLine("3. Hien thi danh sach can bo");
            Console.WriteLine("4. Thoat");
            Console.Write("Nhap lua chon: ");
            int luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    NhapThongTin();
                    break;
                case 2:
                    TimKiemTheoHoTen();
                    break;
                case 3:
                    HienThiDanhSach();
                    break;
                case 4:
                    return;
                default:
                    Console.WriteLine("Lua chon khong hop le!");
                    break;
            }
        }
    }
}

// Chuong trinh chinh
class Program
{
    static void Main(string[] args)
    {
        QLCB qlcb = new QLCB();
        qlcb.ChayChuongTrinh();
    }
}