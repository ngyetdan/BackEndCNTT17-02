﻿using System;
using System.Collections.Generic;

// Lop HocSinh
class HocSinh
{
    private string hoTen;
    private string gioiTinh;
    private double diemToan, diemLy, diemHoa;
    private double diemKyThuat; // Nam
    private double diemNuCong;  // Nu

    public HocSinh() { }
    public void Nhap()
    {
        Console.Write("Nhap ho ten: ");
        hoTen = Console.ReadLine();
        Console.Write("Nhap gioi tinh (Nam/Nu): ");
        gioiTinh = Console.ReadLine();
        Console.Write("Nhap diem Toan: ");
        diemToan = double.Parse(Console.ReadLine());
        Console.Write("Nhap diem Ly: ");
        diemLy = double.Parse(Console.ReadLine());
        Console.Write("Nhap diem Hoa: ");
        diemHoa = double.Parse(Console.ReadLine());

        if (gioiTinh.Equals("Nam", StringComparison.OrdinalIgnoreCase))
        {
            Console.Write("Nhap diem Ky thuat: ");
            diemKyThuat = double.Parse(Console.ReadLine());
        }
        else if (gioiTinh.Equals("Nu", StringComparison.OrdinalIgnoreCase))
        {
            Console.Write("Nhap diem Nu cong: ");
            diemNuCong = double.Parse(Console.ReadLine());
        }
    }

    public void HienThi()
    {
        Console.WriteLine($"Ho ten: {hoTen}, Gioi tinh: {gioiTinh}, Toan: {diemToan}, Ly: {diemLy}, Hoa: {diemHoa}");
        if (gioiTinh.Equals("Nam", StringComparison.OrdinalIgnoreCase))
        {
            Console.WriteLine($"Diem Ky thuat: {diemKyThuat}");
        }
        else if (gioiTinh.Equals("Nu", StringComparison.OrdinalIgnoreCase))
        {
            Console.WriteLine($"Diem Nu cong: {diemNuCong}");
        }
    }

    public string LayGioiTinh() { return gioiTinh; }
    public double LayDiemKyThuat() { return diemKyThuat; }
}

// Chuong trinh chinh
class Program
{
    static void Main(string[] args)
    {
        List<HocSinh> danhSachHocSinh = new List<HocSinh>();

        Console.Write("Nhap so luong hoc sinh: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhap thong tin hoc sinh thu {i + 1}:");
            HocSinh hocSinh = new HocSinh();
            hocSinh.Nhap();
            danhSachHocSinh.Add(hocSinh);
        }

        // Hien thi hoc sinh nam co diem ky thuat >= 8
        Console.WriteLine("\nHoc sinh nam co diem ky thuat >= 8:");
        bool timThay = false;
        foreach (var hocSinh in danhSachHocSinh)
        {
            if (hocSinh.LayGioiTinh().Equals("Nam", StringComparison.OrdinalIgnoreCase) && hocSinh.LayDiemKyThuat() >= 8)
            {
                hocSinh.HienThi();
                timThay = true;
            }
        }
        if (!timThay)
        {
            Console.WriteLine("Khong co hoc sinh nam nao co diem ky thuat >= 8!");
        }

        // Hien thi danh sach: Nam truoc, Nu sau
        Console.WriteLine("\nDanh sach hoc sinh (Nam truoc, Nu sau):");
        Console.WriteLine("Hoc sinh nam:");
        foreach (var hocSinh in danhSachHocSinh)
        {
            if (hocSinh.LayGioiTinh().Equals("Nam", StringComparison.OrdinalIgnoreCase))
            {
                hocSinh.HienThi();
            }
        }
        Console.WriteLine("Hoc sinh nu:");
        foreach (var hocSinh in danhSachHocSinh)
        {
            if (hocSinh.LayGioiTinh().Equals("Nu", StringComparison.OrdinalIgnoreCase))
            {
                hocSinh.HienThi();
            }
        }
    }
}