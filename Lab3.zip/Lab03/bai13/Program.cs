﻿using System;
using System.Collections.Generic;

// Lop cha PTGT
class PTGT
{
    protected string hangSanXuat;
    protected int namSanXuat;
    protected double giaBan;
    protected string mau;

    public PTGT() { }
    public PTGT(string hangSanXuat, int namSanXuat, double giaBan, string mau)
    {
        this.hangSanXuat = hangSanXuat;
        this.namSanXuat = namSanXuat;
        this.giaBan = giaBan;
        this.mau = mau;
    }

    public virtual void Nhap()
    {
        Console.Write("Nhap hang san xuat: ");
        hangSanXuat = Console.ReadLine();
        Console.Write("Nhap nam san xuat: ");
        namSanXuat = int.Parse(Console.ReadLine());
        Console.Write("Nhap gia ban: ");
        giaBan = double.Parse(Console.ReadLine());
        Console.Write("Nhap mau: ");
        mau = Console.ReadLine();
    }

    public virtual void HienThi()
    {
        Console.WriteLine($"Hang san xuat: {hangSanXuat}, Nam san xuat: {namSanXuat}, Gia ban: {giaBan}, Mau: {mau}");
    }

    public string LayMau()
    {
        return mau;
    }

    public int LayNamSanXuat()
    {
        return namSanXuat;
    }
}

// Lop OTo ke thua tu PTGT
class OTo : PTGT
{
    private int soChoNgoi;
    private string kieuDongCo;

    public OTo() : base() { }
    public OTo(string hangSanXuat, int namSanXuat, double giaBan, string mau, int soChoNgoi, string kieuDongCo)
        : base(hangSanXuat, namSanXuat, giaBan, mau)
    {
        this.soChoNgoi = soChoNgoi;
        this.kieuDongCo = kieuDongCo;
    }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap so cho ngoi: ");
        soChoNgoi = int.Parse(Console.ReadLine());
        Console.Write("Nhap kieu dong co: ");
        kieuDongCo = Console.ReadLine();
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"So cho ngoi: {soChoNgoi}, Kieu dong co: {kieuDongCo}");
    }
}

// Lop XeMay ke thua tu PTGT
class XeMay : PTGT
{
    private double congSuat;

    public XeMay() : base() { }
    public XeMay(string hangSanXuat, int namSanXuat, double giaBan, string mau, double congSuat)
        : base(hangSanXuat, namSanXuat, giaBan, mau)
    {
        this.congSuat = congSuat;
    }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap cong suat: ");
        congSuat = double.Parse(Console.ReadLine());
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Cong suat: {congSuat}");
    }
}

// Lop XeTai ke thua tu PTGT
class XeTai : PTGT
{
    private double trongTai;

    public XeTai() : base() { }
    public XeTai(string hangSanXuat, int namSanXuat, double giaBan, string mau, double trongTai)
        : base(hangSanXuat, namSanXuat, giaBan, mau)
    {
        this.trongTai = trongTai;
    }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap trong tai: ");
        trongTai = double.Parse(Console.ReadLine());
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Trong tai: {trongTai}");
    }
}

// Lop QLPTGT quan ly danh sach phuong tien
class QLPTGT
{
    private List<PTGT> danhSachPTGT = new List<PTGT>();

    public void NhapDangKy()
    {
        Console.WriteLine("Ban muon dang ky: 1. O to, 2. Xe may, 3. Xe tai");
        int luaChon = int.Parse(Console.ReadLine());

        PTGT ptgt = null;
        switch (luaChon)
        {
            case 1:
                ptgt = new OTo();
                break;
            case 2:
                ptgt = new XeMay();
                break;
            case 3:
                ptgt = new XeTai();
                break;
            default:
                Console.WriteLine("Lua chon khong hop le!");
                return;
        }

        ptgt.Nhap();
        danhSachPTGT.Add(ptgt);
    }

    public void TimKiem()
    {
        Console.WriteLine("1. Tim kiem theo mau");
        Console.WriteLine("2. Tim kiem theo nam san xuat");
        Console.Write("Nhap lua chon: ");
        int luaChon = int.Parse(Console.ReadLine());

        if (luaChon == 1)
        {
            Console.Write("Nhap mau can tim: ");
            string mau = Console.ReadLine();
            bool timThay = false;

            foreach (var ptgt in danhSachPTGT)
            {
                if (ptgt.LayMau().Equals(mau, StringComparison.OrdinalIgnoreCase))
                {
                    ptgt.HienThi();
                    timThay = true;
                }
            }

            if (!timThay)
            {
                Console.WriteLine("Khong tim thay phuong tien co mau: " + mau);
            }
        }
        else if (luaChon == 2)
        {
            Console.Write("Nhap nam san xuat can tim: ");
            int nam = int.Parse(Console.ReadLine());
            bool timThay = false;

            foreach (var ptgt in danhSachPTGT)
            {
                if (ptgt.LayNamSanXuat() == nam)
                {
                    ptgt.HienThi();
                    timThay = true;
                }
            }

            if (!timThay)
            {
                Console.WriteLine("Khong tim thay phuong tien san xuat nam: " + nam);
            }
        }
        else
        {
            Console.WriteLine("Lua chon khong hop le!");
        }
    }

    public void ChayChuongTrinh()
    {
        while (true)
        {
            Console.WriteLine("\n1. Nhap dang ky phuong tien");
            Console.WriteLine("2. Tim kiem phuong tien");
            Console.WriteLine("3. Thoat");
            Console.Write("Nhap lua chon: ");
            int luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    NhapDangKy();
                    break;
                case 2:
                    TimKiem();
                    break;
                case 3:
                    return;
                default:
                    Console.WriteLine("Lua chon khong hop le!");
                    break;
            }
        }
    }
}

// Chuong trinh chinh
class Program
{
    static void Main(string[] args)
    {
        QLPTGT quanLy = new QLPTGT();
        quanLy.ChayChuongTrinh();
    }
}