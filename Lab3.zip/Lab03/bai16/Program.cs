﻿using System;
using System.Collections.Generic;

// Lop Diem
class Diem
{
    private double hoanhDo;
    private double tungDo;

    public Diem()
    {
        hoanhDo = 0;
        tungDo = 0;
    }

    public Diem(double x, double y)
    {
        hoanhDo = x;
        tungDo = y;
    }

    public void Nhap()
    {
        Console.Write("Nhap hoanh do: ");
        hoanhDo = double.Parse(Console.ReadLine());
        Console.Write("Nhap tung do: ");
        tungDo = double.Parse(Console.ReadLine());
    }

    public void HienThi()
    {
        Console.WriteLine($"({hoanhDo}, {tungDo})");
    }

    public double TinhKhoangCach(Diem d)
    {
        return Math.Sqrt(Math.Pow(hoanhDo - d.hoanhDo, 2) + Math.Pow(tungDo - d.tungDo, 2));
    }

    public double LayHoanhDo() { return hoanhDo; }
    public double LayTungDo() { return tungDo; }
}

// Lop TamGiac
class TamGiac
{
    private Diem diem1, diem2, diem3;

    public TamGiac()
    {
        diem1 = new Diem();
        diem2 = new Diem();
        diem3 = new Diem();
    }

    public TamGiac(Diem d1, Diem d2, Diem d3)
    {
        diem1 = d1;
        diem2 = d2;
        diem3 = d3;
    }

    public void Nhap()
    {
        Console.WriteLine("Nhap diem thu nhat:");
        diem1.Nhap();
        Console.WriteLine("Nhap diem thu hai:");
        diem2.Nhap();
        Console.WriteLine("Nhap diem thu ba:");
        diem3.Nhap();
    }

    public double TinhChuVi()
    {
        double a = diem1.TinhKhoangCach(diem2);
        double b = diem2.TinhKhoangCach(diem3);
        double c = diem3.TinhKhoangCach(diem1);
        return a + b + c;
    }

    public double TinhDienTich()
    {
        double a = diem1.TinhKhoangCach(diem2);
        double b = diem2.TinhKhoangCach(diem3);
        double c = diem3.TinhKhoangCach(diem1);
        double p = (a + b + c) / 2;
        return Math.Sqrt(p * (p - a) * (p - b) * (p - c));
    }
}

// Chuong trinh chinh
class Program
{
    static void Main(string[] args)
    {
        List<TamGiac> danhSachTamGiac = new List<TamGiac>();

        Console.Write("Nhap so luong tam giac: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhap thong tin tam giac thu {i + 1}:");
            TamGiac tamGiac = new TamGiac();
            tamGiac.Nhap();
            danhSachTamGiac.Add(tamGiac);
        }

        double tongChuVi = 0, tongDienTich = 0;
        foreach (var tamGiac in danhSachTamGiac)
        {
            tongChuVi += tamGiac.TinhChuVi();
            tongDienTich += tamGiac.TinhDienTich();
        }

        Console.WriteLine($"Tong chu vi: {tongChuVi}");
        Console.WriteLine($"Tong dien tich: {tongDienTich}");
    }
}