﻿using System;
using System.Collections.Generic;

// Lop Diem
class Diem
{
    private double hoanhDo;
    private double tungDo;

    public Diem()
    {
        hoanhDo = 0;
        tungDo = 0;
    }

    public Diem(double x, double y)
    {
        hoanhDo = x;
        tungDo = y;
    }

    public void Nhap()
    {
        Console.Write("Nhap hoanh do: ");
        hoanhDo = double.Parse(Console.ReadLine());
        Console.Write("Nhap tung do: ");
        tungDo = double.Parse(Console.ReadLine());
    }

    public void HienThi()
    {
        Console.WriteLine($"({hoanhDo}, {tungDo})");
    }

    public double TinhKhoangCach(Diem d)
    {
        return Math.Sqrt(Math.Pow(hoanhDo - d.hoanhDo, 2) + Math.Pow(tungDo - d.tungDo, 2));
    }

    public double LayHoanhDo() { return hoanhDo; }
    public double LayTungDo() { return tungDo; }
}

// Lop HinhTron
class HinhTron
{
    private Diem tam;
    private float banKinh;

    public HinhTron()
    {
        tam = new Diem();
        banKinh = 0;
    }

    public HinhTron(Diem d, float bk)
    {
        tam = d;
        banKinh = bk;
    }

    public void Nhap()
    {
        Console.WriteLine("Nhap tam hinh tron:");
        tam.Nhap();
        Console.Write("Nhap ban kinh: ");
        banKinh = float.Parse(Console.ReadLine());
    }

    public void HienThi()
    {
        Console.Write("Tam: ");
        tam.HienThi();
        Console.WriteLine($"Ban kinh: {banKinh}");
    }

    public double TinhChuVi()
    {
        return 2 * Math.PI * banKinh;
    }

    public double TinhDienTich()
    {
        return Math.PI * banKinh * banKinh;
    }

    public bool GiaoVoi(HinhTron ht)
    {
        double khoangCachTam = tam.TinhKhoangCach(ht.tam);
        return khoangCachTam <= (banKinh + ht.banKinh);
    }

    public Diem LayTam() { return tam; }
    public float LayBanKinh() { return banKinh; }
}

// Chuong trinh chinh
class Program
{
    static void Main(string[] args)
    {
        List<HinhTron> danhSachHinhTron = new List<HinhTron>();

        Console.Write("Nhap so luong hinh tron: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhap thong tin hinh tron thu {i + 1}:");
            HinhTron hinhTron = new HinhTron();
            hinhTron.Nhap();
            danhSachHinhTron.Add(hinhTron);
        }

        int maxGiao = 0;
        HinhTron hinhGiaoNhieuNhat = null;
        for (int i = 0; i < danhSachHinhTron.Count; i++)
        {
            int demGiao = 0;
            for (int j = 0; j < danhSachHinhTron.Count; j++)
            {
                if (i != j && danhSachHinhTron[i].GiaoVoi(danhSachHinhTron[j]))
                {
                    demGiao++;
                }
            }
            if (demGiao > maxGiao)
            {
                maxGiao = demGiao;
                hinhGiaoNhieuNhat = danhSachHinhTron[i];
            }
        }

        if (hinhGiaoNhieuNhat != null)
        {
            Console.WriteLine($"Hinh tron giao voi nhieu hinh tron nhat ({maxGiao} hinh):");
            hinhGiaoNhieuNhat.HienThi();
        }
        else
        {
            Console.WriteLine("Khong co hinh tron nao giao nhau!");
        }
    }
}