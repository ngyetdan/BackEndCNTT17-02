﻿using System;
using System.Collections.Generic;

// Lop cha TaiLieu
class TaiLieu
{
    protected string maTaiLieu;
    protected string tenNhaXuatBan;
    protected int soBanPhatHanh;

    public TaiLieu() { }
    public TaiLieu(string maTaiLieu, string tenNhaXuatBan, int soBanPhatHanh)
    {
        this.maTaiLieu = maTaiLieu;
        this.tenNhaXuatBan = tenNhaXuatBan;
        this.soBanPhatHanh = soBanPhatHanh;
    }

    public virtual void Nhap()
    {
        Console.Write("Nhap ma tai lieu: ");
        maTaiLieu = Console.ReadLine();
        Console.Write("Nhap ten nha xuat ban: ");
        tenNhaXuatBan = Console.ReadLine();
        Console.Write("Nhap so ban phat hanh: ");
        soBanPhatHanh = int.Parse(Console.ReadLine());
    }

    public virtual void HienThi()
    {
        Console.WriteLine($"Ma tai lieu: {maTaiLieu}, Nha xuat ban: {tenNhaXuatBan}, So ban phat hanh: {soBanPhatHanh}");
    }

    public virtual string LayLoaiTaiLieu()
    {
        return "TaiLieu";
    }
}

// Lop Sach ke thua tu TaiLieu
class Sach : TaiLieu
{
    private string tenTacGia;
    private int soTrang;

    public Sach() : base() { }
    public Sach(string maTaiLieu, string tenNhaXuatBan, int soBanPhatHanh, string tenTacGia, int soTrang)
        : base(maTaiLieu, tenNhaXuatBan, soBanPhatHanh)
    {
        this.tenTacGia = tenTacGia;
        this.soTrang = soTrang;
    }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap ten tac gia: ");
        tenTacGia = Console.ReadLine();
        Console.Write("Nhap so trang: ");
        soTrang = int.Parse(Console.ReadLine());
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Ten tac gia: {tenTacGia}, So trang: {soTrang}");
    }

    public override string LayLoaiTaiLieu()
    {
        return "Sach";
    }
}

// Lop TapChi ke thua tu TaiLieu
class TapChi : TaiLieu
{
    private int soPhatHanh;
    private int thangPhatHanh;

    public TapChi() : base() { }
    public TapChi(string maTaiLieu, string tenNhaXuatBan, int soBanPhatHanh, int soPhatHanh, int thangPhatHanh)
        : base(maTaiLieu, tenNhaXuatBan, soBanPhatHanh)
    {
        this.soPhatHanh = soPhatHanh;
        this.thangPhatHanh = thangPhatHanh;
    }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap so phat hanh: ");
        soPhatHanh = int.Parse(Console.ReadLine());
        Console.Write("Nhap thang phat hanh: ");
        thangPhatHanh = int.Parse(Console.ReadLine());
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"So phat hanh: {soPhatHanh}, Thang phat hanh: {thangPhatHanh}");
    }

    public override string LayLoaiTaiLieu()
    {
        return "TapChi";
    }
}

// Lop Bao ke thua tu TaiLieu
class Bao : TaiLieu
{
    private string ngayPhatHanh;

    public Bao() : base() { }
    public Bao(string maTaiLieu, string tenNhaXuatBan, int soBanPhatHanh, string ngayPhatHanh)
        : base(maTaiLieu, tenNhaXuatBan, soBanPhatHanh)
    {
        this.ngayPhatHanh = ngayPhatHanh;
    }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap ngay phat hanh: ");
        ngayPhatHanh = Console.ReadLine();
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Ngay phat hanh: {ngayPhatHanh}");
    }

    public override string LayLoaiTaiLieu()
    {
        return "Bao";
    }
}

// Lop QuanLyTaiLieu quan ly danh sach tai lieu
class QuanLyTaiLieu
{
    private List<TaiLieu> danhSachTaiLieu = new List<TaiLieu>();

    public void NhapThongTin()
    {
        Console.WriteLine("Ban muon nhap thong tin cho: 1. Sach, 2. Tap chi, 3. Bao");
        int luaChon = int.Parse(Console.ReadLine());

        TaiLieu taiLieu = null;
        switch (luaChon)
        {
            case 1:
                taiLieu = new Sach();
                break;
            case 2:
                taiLieu = new TapChi();
                break;
            case 3:
                taiLieu = new Bao();
                break;
            default:
                Console.WriteLine("Lua chon khong hop le!");
                return;
        }

        taiLieu.Nhap();
        danhSachTaiLieu.Add(taiLieu);
    }

    public void HienThiDanhSach()
    {
        if (danhSachTaiLieu.Count == 0)
        {
            Console.WriteLine("Danh sach trong!");
            return;
        }

        foreach (var taiLieu in danhSachTaiLieu)
        {
            taiLieu.HienThi();
            Console.WriteLine("-----------------");
        }
    }

    public void TimKiemTheoLoai()
    {
        Console.Write("Nhap loai tai lieu can tim (Sach/TapChi/Bao): ");
        string loai = Console.ReadLine();
        bool timThay = false;

        foreach (var taiLieu in danhSachTaiLieu)
        {
            if (taiLieu.LayLoaiTaiLieu().Equals(loai, StringComparison.OrdinalIgnoreCase))
            {
                taiLieu.HienThi();
                timThay = true;
            }
        }

        if (!timThay)
        {
            Console.WriteLine($"Khong tim thay tai lieu loai {loai}");
        }
    }

    public void ChayChuongTrinh()
    {
        while (true)
        {
            Console.WriteLine("\n1. Nhap thong tin tai lieu");
            Console.WriteLine("2. Hien thi danh sach tai lieu");
            Console.WriteLine("3. Tim kiem theo loai tai lieu");
            Console.WriteLine("4. Thoat");
            Console.Write("Nhap lua chon: ");
            int luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    NhapThongTin();
                    break;
                case 2:
                    HienThiDanhSach();
                    break;
                case 3:
                    TimKiemTheoLoai();
                    break;
                case 4:
                    return;
                default:
                    Console.WriteLine("Lua chon khong hop le!");
                    break;
            }
        }
    }
}

// Chuong trinh chinh
class Program
{
    static void Main(string[] args)
    {
        QuanLyTaiLieu qlTaiLieu = new QuanLyTaiLieu();
        qlTaiLieu.ChayChuongTrinh();
    }
}