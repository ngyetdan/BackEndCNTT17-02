﻿using System;

// Lop PhanSo
class PhanSo
{
    private int tuSo;
    private int mauSo;

    public PhanSo()
    {
        tuSo = 0;
        mauSo = 1;
    }

    public PhanSo(int tu, int mau)
    {
        tuSo = tu;
        if (mau == 0) throw new Exception("Mau so khong the bang 0!");
        mauSo = mau;
    }

    public void Nhap()
    {
        Console.Write("Nhap tu so: ");
        tuSo = int.Parse(Console.ReadLine());
        Console.Write("Nhap mau so: ");
        mauSo = int.Parse(Console.ReadLine());
        if (mauSo == 0) throw new Exception("Mau so khong the bang 0!");
    }

    public void HienThi()
    {
        Console.WriteLine($"{tuSo}/{mauSo}");
    }

    private int UCLN(int a, int b)
    {
        a = Math.Abs(a);
        b = Math.Abs(b);
        while (b != 0)
        {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    public void RutGon()
    {
        int ucln = UCLN(tuSo, mauSo);
        tuSo /= ucln;
        mauSo /= ucln;
        if (mauSo < 0)
        {
            tuSo = -tuSo;
            mauSo = -mauSo;
        }
    }

    public PhanSo Cong(PhanSo ps)
    {
        int tu = tuSo * ps.mauSo + ps.tuSo * mauSo;
        int mau = mauSo * ps.mauSo;
        PhanSo ketQua = new PhanSo(tu, mau);
        ketQua.RutGon();
        return ketQua;
    }

    public PhanSo Tru(PhanSo ps)
    {
        int tu = tuSo * ps.mauSo - ps.tuSo * mauSo;
        int mau = mauSo * ps.mauSo;
        PhanSo ketQua = new PhanSo(tu, mau);
        ketQua.RutGon();
        return ketQua;
    }

    public PhanSo Nhan(PhanSo ps)
    {
        int tu = tuSo * ps.tuSo;
        int mau = mauSo * ps.mauSo;
        PhanSo ketQua = new PhanSo(tu, mau);
        ketQua.RutGon();
        return ketQua;
    }

    public PhanSo Chia(PhanSo ps)
    {
        if (ps.tuSo == 0) throw new Exception("Khong the chia cho 0!");
        int tu = tuSo * ps.mauSo;
        int mau = mauSo * ps.tuSo;
        PhanSo ketQua = new PhanSo(tu, mau);
        ketQua.RutGon();
        return ketQua;
    }
}

// Chuong trinh chinh
class Program
{
    static void Main(string[] args)
    {
        PhanSo ps1 = new PhanSo();
        PhanSo ps2 = new PhanSo();

        Console.WriteLine("Nhap phan so thu nhat:");
        ps1.Nhap();
        Console.WriteLine("Nhap phan so thu hai:");
        ps2.Nhap();

        while (true)
        {
            Console.WriteLine("\n1. Cong");
            Console.WriteLine("2. Tru");
            Console.WriteLine("3. Nhan");
            Console.WriteLine("4. Chia");
            Console.WriteLine("5. Thoat");
            Console.Write("Nhap lua chon: ");
            int luaChon = int.Parse(Console.ReadLine());

            try
            {
                switch (luaChon)
                {
                    case 1:
                        Console.Write("Tong: ");
                        ps1.Cong(ps2).HienThi();
                        break;
                    case 2:
                        Console.Write("Hieu: ");
                        ps1.Tru(ps2).HienThi();
                        break;
                    case 3:
                        Console.Write("Tich: ");
                        ps1.Nhan(ps2).HienThi();
                        break;
                    case 4:
                        Console.Write("Thuong: ");
                        ps1.Chia(ps2).HienThi();
                        break;
                    case 5:
                        return;
                    default:
                        Console.WriteLine("Lua chon khong hop le!");
                        break;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}