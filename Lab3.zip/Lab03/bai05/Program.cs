﻿using System;
using System.Collections.Generic;

// Lop Nguoi quan ly thong tin ca nhan
class Nguoi
{
    private string hoTen;
    private int namSinh;
    private string soCMND;

    public Nguoi() { }
    public Nguoi(string hoTen, int namSinh, string soCMND)
    {
        this.hoTen = hoTen;
        this.namSinh = namSinh;
        this.soCMND = soCMND;
    }

    public void Nhap()
    {
        Console.Write("Nhap ho ten: ");
        hoTen = Console.ReadLine();
        Console.Write("Nhap nam sinh: ");
        namSinh = int.Parse(Console.ReadLine());
        Console.Write("Nhap so CMND: ");
        soCMND = Console.ReadLine();
    }

    public void HienThi()
    {
        Console.WriteLine($"Ho ten: {hoTen}, Nam sinh: {namSinh}, So CMND: {soCMND}");
    }

    public string LayHoTen()
    {
        return hoTen;
    }
}

// Lop KhachSan quan ly thong tin khach tro
class KhachSan
{
    private Nguoi thongTinCaNhan;
    private int soNgayTro;
    private string loaiPhong;
    private double giaPhong;

    public KhachSan()
    {
        thongTinCaNhan = new Nguoi();
    }

    public void Nhap()
    {
        thongTinCaNhan.Nhap();
        Console.Write("Nhap so ngay tro: ");
        soNgayTro = int.Parse(Console.ReadLine());
        Console.Write("Nhap loai phong: ");
        loaiPhong = Console.ReadLine();
        Console.Write("Nhap gia phong: ");
        giaPhong = double.Parse(Console.ReadLine());
    }

    public void HienThi()
    {
        thongTinCaNhan.HienThi();
        Console.WriteLine($"So ngay tro: {soNgayTro}, Loai phong: {loaiPhong}, Gia phong: {giaPhong}");
    }

    public double TinhTien()
    {
        return soNgayTro * giaPhong;
    }

    public string LayHoTen()
    {
        return thongTinCaNhan.LayHoTen();
    }
}

// Lop quan ly danh sach khach tro
class QuanLyKhachSan
{
    private List<KhachSan> danhSachKhachTro = new List<KhachSan>();

    public void NhapDanhSach()
    {
        Console.Write("Nhap so luong khach tro: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhap thong tin khach tro thu {i + 1}:");
            KhachSan khach = new KhachSan();
            khach.Nhap();
            danhSachKhachTro.Add(khach);
        }
    }

    public void HienThiDanhSach()
    {
        if (danhSachKhachTro.Count == 0)
        {
            Console.WriteLine("Danh sach trong!");
            return;
        }

        foreach (var khach in danhSachKhachTro)
        {
            khach.HienThi();
            Console.WriteLine("-----------------");
        }
    }

    public void TimKiemTheoHoTen()
    {
        Console.Write("Nhap ho ten can tim: ");
        string hoTen = Console.ReadLine();
        bool timThay = false;

        foreach (var khach in danhSachKhachTro)
        {
            if (khach.LayHoTen().Equals(hoTen, StringComparison.OrdinalIgnoreCase))
            {
                khach.HienThi();
                timThay = true;
            }
        }

        if (!timThay)
        {
            Console.WriteLine("Khong tim thay khach co ho ten: " + hoTen);
        }
    }

    public void TinhTienThanhToan()
    {
        Console.Write("Nhap ho ten khach can thanh toan: ");
        string hoTen = Console.ReadLine();
        bool timThay = false;

        foreach (var khach in danhSachKhachTro)
        {
            if (khach.LayHoTen().Equals(hoTen, StringComparison.OrdinalIgnoreCase))
            {
                double tien = khach.TinhTien();
                Console.WriteLine($"Khach {hoTen} phai thanh toan: {tien} VND");
                timThay = true;
                break;
            }
        }

        if (!timThay)
        {
            Console.WriteLine("Khong tim thay khach co ho ten: " + hoTen);
        }
    }

    public void ChayChuongTrinh()
    {
        while (true)
        {
            Console.WriteLine("\n1. Nhap danh sach khach tro");
            Console.WriteLine("2. Hien thi danh sach khach tro");
            Console.WriteLine("3. Tim kiem theo ho ten");
            Console.WriteLine("4. Tinh tien thanh toan");
            Console.WriteLine("5. Thoat");
            Console.Write("Nhap lua chon: ");
            int luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    NhapDanhSach();
                    break;
                case 2:
                    HienThiDanhSach();
                    break;
                case 3:
                    TimKiemTheoHoTen();
                    break;
                case 4:
                    TinhTienThanhToan();
                    break;
                case 5:
                    return;
                default:
                    Console.WriteLine("Lua chon khong hop le!");
                    break;
            }
        }
    }
}

// Chuong trinh chinh
class Program
{
    static void Main(string[] args)
    {
        QuanLyKhachSan quanLy = new QuanLyKhachSan();
        quanLy.ChayChuongTrinh();
    }
}