﻿using System;
using System.Collections.Generic;

// Lop cha HoiVien
class HoiVien
{
    protected string hoTen;
    protected string diaChi;

    public HoiVien() { }
    public virtual void Nhap()
    {
        Console.Write("Nhap ho ten: ");
        hoTen = Console.ReadLine();
        Console.Write("Nhap dia chi: ");
        diaChi = Console.ReadLine();
    }

    public virtual void HienThi()
    {
        Console.WriteLine($"Ho ten: {hoTen}, Dia chi: {diaChi}");
    }

    public virtual bool DaCoGiaDinh() { return false; }
    public virtual bool DaCoNguoiYeu() { return false; }
    public virtual string LayNgayCuoi() { return ""; }
}

// Lop HoiVienCoGiaDinh ke thua tu HoiVien
class HoiVienCoGiaDinh : HoiVien
{
    private string hoTenVo;
    private string ngayCuoi;

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap ho ten vo: ");
        hoTenVo = Console.ReadLine();
        Console.Write("Nhap ngay cuoi (dd/mm/yyyy): ");
        ngayCuoi = Console.ReadLine();
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Ho ten vo: {hoTenVo}, Ngay cuoi: {ngayCuoi}");
    }

    public override bool DaCoGiaDinh() { return true; }
    public override string LayNgayCuoi() { return ngayCuoi; }
}

// Lop HoiVienCoNguoiYeu ke thua tu HoiVien
class HoiVienCoNguoiYeu : HoiVien
{
    private string hoTenNguoiYeu;
    private string soDienThoai;

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap ho ten nguoi yeu: ");
        hoTenNguoiYeu = Console.ReadLine();
        Console.Write("Nhap so dien thoai nguoi yeu: ");
        soDienThoai = Console.ReadLine();
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Ho ten nguoi yeu: {hoTenNguoiYeu}, So dien thoai: {soDienThoai}");
    }

    public override bool DaCoNguoiYeu() { return true; }
}

// Chuong trinh chinh
class Program
{
    static void Main(string[] args)
    {
        List<HoiVien> danhSachHoiVien = new List<HoiVien>();

        Console.Write("Nhap so luong hoi vien: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhap thong tin hoi vien thu {i + 1}:");
            Console.Write("Trang thai (1: Co gia dinh, 2: Co nguoi yeu, 3: Chua co nguoi yeu): ");
            int trangThai = int.Parse(Console.ReadLine());

            HoiVien hoiVien = null;
            switch (trangThai)
            {
                case 1:
                    hoiVien = new HoiVienCoGiaDinh();
                    break;
                case 2:
                    hoiVien = new HoiVienCoNguoiYeu();
                    break;
                case 3:
                    hoiVien = new HoiVien();
                    break;
                default:
                    Console.WriteLine("Trang thai khong hop le!");
                    i--;
                    continue;
            }
            hoiVien.Nhap();
            danhSachHoiVien.Add(hoiVien);
        }

        // Tim kiem hoi vien co ngay cuoi 11/11/2011
        Console.WriteLine("\nHoi vien co ngay cuoi 11/11/2011:");
        bool timThay = false;
        foreach (var hoiVien in danhSachHoiVien)
        {
            if (hoiVien.DaCoGiaDinh() && hoiVien.LayNgayCuoi() == "11/11/2011")
            {
                hoiVien.HienThi();
                timThay = true;
            }
        }
        if (!timThay)
        {
            Console.WriteLine("Khong co hoi vien nao co ngay cuoi 11/11/2011!");
        }

        // Hien thi hoi vien co nguoi yeu nhung chua co gia dinh
        Console.WriteLine("\nHoi vien co nguoi yeu nhung chua co gia dinh:");
        timThay = false;
        foreach (var hoiVien in danhSachHoiVien)
        {
            if (hoiVien.DaCoNguoiYeu() && !hoiVien.DaCoGiaDinh())
            {
                hoiVien.HienThi();
                timThay = true;
            }
        }
        if (!timThay)
        {
            Console.WriteLine("Khong co hoi vien nao co nguoi yeu nhung chua co gia dinh!");
        }
    }
}