﻿using System;
using System.Collections.Generic;

// Lop HoTen
class HoTen
{
    public string ho;
    public string tenDem;
    public string ten;

    public void Nhap()
    {
        Console.Write("Nhap ho: ");
        ho = Console.ReadLine();
        Console.Write("Nhap ten dem: ");
        tenDem = Console.ReadLine();
        Console.Write("Nhap ten: ");
        ten = Console.ReadLine();
    }

    public override string ToString()
    {
        return $"{ho} {tenDem} {ten}";
    }
}

// Lop QueQuan
class QueQuan
{
    public string xa;
    public string huyen;
    public string tinh;

    public void Nhap()
    {
        Console.Write("Nhap xa: ");
        xa = Console.ReadLine();
        Console.Write("Nhap huyen: ");
        huyen = Console.ReadLine();
        Console.Write("Nhap tinh: ");
        tinh = Console.ReadLine();
    }

    public override string ToString()
    {
        return $"{xa}, {huyen}, {tinh}";
    }
}

// Lop DiemThi
class DiemThi
{
    public double toan;
    public double ly;
    public double hoa;

    public void Nhap()
    {
        Console.Write("Nhap diem toan: ");
        toan = double.Parse(Console.ReadLine());
        Console.Write("Nhap diem ly: ");
        ly = double.Parse(Console.ReadLine());
        Console.Write("Nhap diem hoa: ");
        hoa = double.Parse(Console.ReadLine());
    }

    public double TinhTongDiem()
    {
        return toan + ly + hoa;
    }

    public override string ToString()
    {
        return $"Toan: {toan}, Ly: {ly}, Hoa: {hoa}";
    }
}

// Lop ThiSinh
class ThiSinh
{
    private HoTen hoTen;
    private QueQuan queQuan;
    private string truong;
    private int tuoi;
    private string soBaoDanh;
    private DiemThi diemThi;

    public ThiSinh()
    {
        hoTen = new HoTen();
        queQuan = new QueQuan();
        diemThi = new DiemThi();
    }

    public void Nhap()
    {
        Console.WriteLine("Nhap ho ten:");
        hoTen.Nhap();
        Console.WriteLine("Nhap que quan:");
        queQuan.Nhap();
        Console.Write("Nhap truong: ");
        truong = Console.ReadLine();
        Console.Write("Nhap tuoi: ");
        tuoi = int.Parse(Console.ReadLine());
        Console.Write("Nhap so bao danh: ");
        soBaoDanh = Console.ReadLine();
        Console.WriteLine("Nhap diem thi:");
        diemThi.Nhap();
    }

    public void HienThi()
    {
        Console.WriteLine($"| {hoTen,-20} | {queQuan,-30} | {soBaoDanh,-10} | {diemThi,-30} |");
    }

    public double LayTongDiem()
    {
        return diemThi.TinhTongDiem();
    }
}

// Chuong trinh chinh
class Program
{
    static void Main(string[] args)
    {
        List<ThiSinh> danhSachThiSinh = new List<ThiSinh>();

        // Nhap danh sach
        Console.Write("Nhap so luong thi sinh: ");
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhap thong tin thi sinh thu {i + 1}:");
            ThiSinh thiSinh = new ThiSinh();
            thiSinh.Nhap();
            danhSachThiSinh.Add(thiSinh);
        }

        // Hien thi thi sinh co tong diem > 15
        Console.WriteLine("\nThi sinh co tong diem > 15:");
        foreach (var thiSinh in danhSachThiSinh)
        {
            if (thiSinh.LayTongDiem() > 15)
            {
                thiSinh.HienThi();
            }
        }

        // Sap xep theo tong diem giam dan
        danhSachThiSinh.Sort((ts1, ts2) => ts2.LayTongDiem().CompareTo(ts1.LayTongDiem()));

        // Hien thi danh sach
        Console.WriteLine("\nDanh sach thi sinh sau khi sap xep:");
        Console.WriteLine($"| {"Ho ten",-20} | {"Que quan",-30} | {"So bao danh",-10} | {"Diem thi",-30} |");
        Console.WriteLine(new string('-', 100));
        foreach (var thiSinh in danhSachThiSinh)
        {
            thiSinh.HienThi();
        }
    }
}