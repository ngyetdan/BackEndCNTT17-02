﻿using System;
using System.Collections.Generic;

// Lop Nguoi quan ly thong tin ca nhan
class Nguoi
{
    private string soCMND;
    private string hoTen;
    private int tuoi;
    private int namSinh;
    private string ngheNghiep;

    public Nguoi() { }
    public Nguoi(string soCMND, string hoTen, int tuoi, int namSinh, string ngheNghiep)
    {
        this.soCMND = soCMND;
        this.hoTen = hoTen;
        this.tuoi = tuoi;
        this.namSinh = namSinh;
        this.ngheNghiep = ngheNghiep;
    }

    public void Nhap()
    {
        Console.Write("Nhap so CMND: ");
        soCMND = Console.ReadLine();
        Console.Write("Nhap ho ten: ");
        hoTen = Console.ReadLine();
        Console.Write("Nhap tuoi: ");
        tuoi = int.Parse(Console.ReadLine());
        Console.Write("Nhap nam sinh: ");
        namSinh = int.Parse(Console.ReadLine());
        Console.Write("Nhap nghe nghiep: ");
        ngheNghiep = Console.ReadLine();
    }

    public void HienThi()
    {
        Console.WriteLine($"So CMND: {soCMND}, Ho ten: {hoTen}, Tuoi: {tuoi}, Nam sinh: {namSinh}, Nghe nghiep: {ngheNghiep}");
    }

    public string LayHoTen()
    {
        return hoTen;
    }
}

// Lop HoDan quan ly thong tin mot ho dan
class HoDan
{
    private int soThanhVien;
    private string soNha;
    private List<Nguoi> danhSachThanhVien;

    public HoDan()
    {
        danhSachThanhVien = new List<Nguoi>();
    }

    public void Nhap()
    {
        Console.Write("Nhap so nha: ");
        soNha = Console.ReadLine();
        Console.Write("Nhap so thanh vien trong ho: ");
        soThanhVien = int.Parse(Console.ReadLine());

        for (int i = 0; i < soThanhVien; i++)
        {
            Console.WriteLine($"Nhap thong tin thanh vien thu {i + 1}:");
            Nguoi nguoi = new Nguoi();
            nguoi.Nhap();
            danhSachThanhVien.Add(nguoi);
        }
    }

    public void HienThi()
    {
        Console.WriteLine($"So nha: {soNha}, So thanh vien: {soThanhVien}");
        Console.WriteLine("Danh sach thanh vien:");
        foreach (var thanhVien in danhSachThanhVien)
        {
            thanhVien.HienThi();
        }
    }

    public string LaySoNha()
    {
        return soNha;
    }

    public bool CoThanhVien(string hoTen)
    {
        foreach (var thanhVien in danhSachThanhVien)
        {
            if (thanhVien.LayHoTen().Equals(hoTen, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }
        return false;
    }
}

// Lop KhuPho quan ly danh sach ho dan
class KhuPho
{
    private List<HoDan> danhSachHoDan = new List<HoDan>();

    public void NhapDanhSach()
    {
        Console.Write("Nhap so luong ho dan: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhap thong tin ho dan thu {i + 1}:");
            HoDan hoDan = new HoDan();
            hoDan.Nhap();
            danhSachHoDan.Add(hoDan);
        }
    }

    public void TimKiem()
    {
        Console.WriteLine("1. Tim kiem theo ho ten");
        Console.WriteLine("2. Tim kiem theo so nha");
        Console.Write("Nhap lua chon: ");
        int luaChon = int.Parse(Console.ReadLine());

        if (luaChon == 1)
        {
            Console.Write("Nhap ho ten can tim: ");
            string hoTen = Console.ReadLine();
            bool timThay = false;

            foreach (var hoDan in danhSachHoDan)
            {
                if (hoDan.CoThanhVien(hoTen))
                {
                    hoDan.HienThi();
                    timThay = true;
                }
            }

            if (!timThay)
            {
                Console.WriteLine("Khong tim thay ho dan co thanh vien ten: " + hoTen);
            }
        }
        else if (luaChon == 2)
        {
            Console.Write("Nhap so nha can tim: ");
            string soNha = Console.ReadLine();
            bool timThay = false;

            foreach (var hoDan in danhSachHoDan)
            {
                if (hoDan.LaySoNha().Equals(soNha))
                {
                    hoDan.HienThi();
                    timThay = true;
                    break;
                }
            }

            if (!timThay)
            {
                Console.WriteLine("Khong tim thay ho dan co so nha: " + soNha);
            }
        }
        else
        {
            Console.WriteLine("Lua chon khong hop le!");
        }
    }

    public void HienThiDanhSach()
    {
        if (danhSachHoDan.Count == 0)
        {
            Console.WriteLine("Danh sach trong!");
            return;
        }

        foreach (var hoDan in danhSachHoDan)
        {
            hoDan.HienThi();
            Console.WriteLine("-----------------");
        }
    }

    public void ChayChuongTrinh()
    {
        while (true)
        {
            Console.WriteLine("\n1. Nhap danh sach ho dan");
            Console.WriteLine("2. Tim kiem thong tin");
            Console.WriteLine("3. Hien thi danh sach ho dan");
            Console.WriteLine("4. Thoat");
            Console.Write("Nhap lua chon: ");
            int luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    NhapDanhSach();
                    break;
                case 2:
                    TimKiem();
                    break;
                case 3:
                    HienThiDanhSach();
                    break;
                case 4:
                    return;
                default:
                    Console.WriteLine("Lua chon khong hop le!");
                    break;
            }
        }
    }
}

// Chuong trinh chinh
class Program
{
    static void Main(string[] args)
    {
        KhuPho khuPho = new KhuPho();
        khuPho.ChayChuongTrinh();
    }
}