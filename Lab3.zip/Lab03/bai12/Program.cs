﻿using System;

// Lop MaTran
class MaTran
{
    private int soDong;
    private int soCot;
    private double[,] mang;

    public MaTran()
    {
        soDong = 0;
        soCot = 0;
        mang = null;
    }

    public MaTran(int n, int m)
    {
        soDong = n;
        soCot = m;
        mang = new double[n, m];
    }

    public void Nhap()
    {
        Console.Write("Nhap so dong: ");
        soDong = int.Parse(Console.ReadLine());
        Console.Write("Nhap so cot: ");
        soCot = int.Parse(Console.ReadLine());
        mang = new double[soDong, soCot];

        for (int i = 0; i < soDong; i++)
        {
            for (int j = 0; j < soCot; j++)
            {
                Console.Write($"Nhap phan tu [{i},{j}]: ");
                mang[i, j] = double.Parse(Console.ReadLine());
            }
        }
    }

    public void HienThi()
    {
        for (int i = 0; i < soDong; i++)
        {
            for (int j = 0; j < soCot; j++)
            {
                Console.Write($"{mang[i, j]} ");
            }
            Console.WriteLine();
        }
    }

    public MaTran Cong(MaTran mt)
    {
        if (soDong != mt.soDong || soCot != mt.soCot)
        {
            throw new Exception("Hai ma tran khong cung kich thuoc!");
        }
        MaTran ketQua = new MaTran(soDong, soCot);
        for (int i = 0; i < soDong; i++)
        {
            for (int j = 0; j < soCot; j++)
            {
                ketQua.mang[i, j] = mang[i, j] + mt.mang[i, j];
            }
        }
        return ketQua;
    }

    public MaTran Tru(MaTran mt)
    {
        if (soDong != mt.soDong || soCot != mt.soCot)
        {
            throw new Exception("Hai ma tran khong cung kich thuoc!");
        }
        MaTran ketQua = new MaTran(soDong, soCot);
        for (int i = 0; i < soDong; i++)
        {
            for (int j = 0; j < soCot; j++)
            {
                ketQua.mang[i, j] = mang[i, j] - mt.mang[i, j];
            }
        }
        return ketQua;
    }

    public MaTran Nhan(MaTran mt)
    {
        if (soCot != mt.soDong)
        {
            throw new Exception("Khong the nhan hai ma tran!");
        }
        MaTran ketQua = new MaTran(soDong, mt.soCot);
        for (int i = 0; i < soDong; i++)
        {
            for (int j = 0; j < mt.soCot; j++)
            {
                ketQua.mang[i, j] = 0;
                for (int k = 0; k < soCot; k++)
                {
                    ketQua.mang[i, j] += mang[i, k] * mt.mang[k, j];
                }
            }
        }
        return ketQua;
    }
}

// Chuong trinh chinh
class Program
{
    static void Main(string[] args)
    {
        MaTran mt1 = new MaTran();
        MaTran mt2 = new MaTran();

        Console.WriteLine("Nhap ma tran thu nhat:");
        mt1.Nhap();
        Console.WriteLine("Nhap ma tran thu hai:");
        mt2.Nhap();

        while (true)
        {
            Console.WriteLine("\n1. Tinh tong");
            Console.WriteLine("2. Tinh hieu");
            Console.WriteLine("3. Tinh tich");
            Console.WriteLine("4. Thoat");
            Console.Write("Nhap lua chon: ");
            int luaChon = int.Parse(Console.ReadLine());

            try
            {
                switch (luaChon)
                {
                    case 1:
                        Console.WriteLine("Tong:");
                        mt1.Cong(mt2).HienThi();
                        break;
                    case 2:
                        Console.WriteLine("Hieu:");
                        mt1.Tru(mt2).HienThi();
                        break;
                    case 3:
                        Console.WriteLine("Tich:");
                        mt1.Nhan(mt2).HienThi();
                        break;
                    case 4:
                        return;
                    default:
                        Console.WriteLine("Lua chon khong hop le!");
                        break;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}