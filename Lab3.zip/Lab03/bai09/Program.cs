﻿using System;
using System.Collections.Generic;

// Lop KhachHang quan ly thong tin ho dan
class KhachHang
{
    private string hoTenChuHo;
    private string soNha;
    private string maSoCongTo;

    public KhachHang() { }
    public KhachHang(string hoTenChuHo, string soNha, string maSoCongTo)
    {
        this.hoTenChuHo = hoTenChuHo;
        this.soNha = soNha;
        this.maSoCongTo = maSoCongTo;
    }

    public void Nhap()
    {
        Console.Write("Nhap ho ten chu ho: ");
        hoTenChuHo = Console.ReadLine();
        Console.Write("Nhap so nha: ");
        soNha = Console.ReadLine();
        Console.Write("Nhap ma so cong to: ");
        maSoCongTo = Console.ReadLine();
    }

    public void HienThi()
    {
        Console.WriteLine($"Ho ten chu ho: {hoTenChuHo}, So nha: {soNha}, Ma so cong to: {maSoCongTo}");
    }
}

// Lop BienLai quan ly thong tin bien lai
class BienLai
{
    private KhachHang thongTinKhachHang;
    private int chiSoCu;
    private int chiSoMoi;
    private double soTienPhaiTra;

    public BienLai()
    {
        thongTinKhachHang = new KhachHang();
    }

    public void Nhap()
    {
        thongTinKhachHang.Nhap();
        Console.Write("Nhap chi so cu: ");
        chiSoCu = int.Parse(Console.ReadLine());
        Console.Write("Nhap chi so moi: ");
        chiSoMoi = int.Parse(Console.ReadLine());
        TinhTien();
    }

    public void HienThi()
    {
        thongTinKhachHang.HienThi();
        Console.WriteLine($"Chi so cu: {chiSoCu}, Chi so moi: {chiSoMoi}, So tien phai tra: {soTienPhaiTra}");
    }

    public void TinhTien()
    {
        int soDien = chiSoMoi - chiSoCu;
        if (soDien < 50)
        {
            soTienPhaiTra = soDien * 1250;
        }
        else if (soDien < 100)
        {
            soTienPhaiTra = soDien * 1500;
        }
        else
        {
            soTienPhaiTra = soDien * 2000;
        }
    }
}

// Lop quan ly danh sach bien lai
class QuanLyBienLai
{
    private List<BienLai> danhSachBienLai = new List<BienLai>();

    public void NhapDanhSach()
    {
        Console.Write("Nhap so luong ho dan: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhap thong tin bien lai thu {i + 1}:");
            BienLai bienLai = new BienLai();
            bienLai.Nhap();
            danhSachBienLai.Add(bienLai);
        }
    }

    public void HienThiDanhSach()
    {
        if (danhSachBienLai.Count == 0)
        {
            Console.WriteLine("Danh sach trong!");
            return;
        }

        foreach (var bienLai in danhSachBienLai)
        {
            bienLai.HienThi();
            Console.WriteLine("-----------------");
        }
    }

    public void ChayChuongTrinh()
    {
        while (true)
        {
            Console.WriteLine("\n1. Nhap danh sach bien lai");
            Console.WriteLine("2. Hien thi danh sach bien lai");
            Console.WriteLine("3. Thoat");
            Console.Write("Nhap lua chon: ");
            int luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    NhapDanhSach();
                    break;
                case 2:
                    HienThiDanhSach();
                    break;
                case 3:
                    return;
                default:
                    Console.WriteLine("Lua chon khong hop le!");
                    break;
            }
        }
    }
}

// Chuong trinh chinh
class Program
{
    static void Main(string[] args)
    {
        QuanLyBienLai quanLy = new QuanLyBienLai();
        quanLy.ChayChuongTrinh();
    }
}