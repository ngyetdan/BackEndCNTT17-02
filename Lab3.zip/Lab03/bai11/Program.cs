﻿using System;

// Lop SoPhuc
class SoPhuc
{
    private double phanThuc;
    private double phanAo;

    public SoPhuc()
    {
        phanThuc = 0;
        phanAo = 0;
    }

    public SoPhuc(double a, double b)
    {
        phanThuc = a;
        phanAo = b;
    }

    public void Nhap()
    {
        Console.Write("Nhap phan thuc: ");
        phanThuc = double.Parse(Console.ReadLine());
        Console.Write("Nhap phan ao: ");
        phanAo = double.Parse(Console.ReadLine());
    }

    public void HienThi()
    {
        Console.WriteLine($"{phanThuc} + {phanAo}i");
    }

    public SoPhuc Cong(SoPhuc sp)
    {
        return new SoPhuc(phanThuc + sp.phanThuc, phanAo + sp.phanAo);
    }

    public SoPhuc Tru(SoPhuc sp)
    {
        return new SoPhuc(phanThuc - sp.phanThuc, phanAo - sp.phanAo);
    }

    public SoPhuc Nhan(SoPhuc sp)
    {
        double thuc = phanThuc * sp.phanThuc - phanAo * sp.phanAo;
        double ao = phanThuc * sp.phanAo + phanAo * sp.phanThuc;
        return new SoPhuc(thuc, ao);
    }

    public SoPhuc Chia(SoPhuc sp)
    {
        double mau = sp.phanThuc * sp.phanThuc + sp.phanAo * sp.phanAo;
        if (mau == 0) throw new Exception("Khong the chia cho 0!");
        double thuc = (phanThuc * sp.phanThuc + phanAo * sp.phanAo) / mau;
        double ao = (phanAo * sp.phanThuc - phanThuc * sp.phanAo) / mau;
        return new SoPhuc(thuc, ao);
    }
}

// Chuong trinh chinh
class Program
{
    static void Main(string[] args)
    {
        SoPhuc sp1 = new SoPhuc();
        SoPhuc sp2 = new SoPhuc();

        Console.WriteLine("Nhap so phuc thu nhat:");
        sp1.Nhap();
        Console.WriteLine("Nhap so phuc thu hai:");
        sp2.Nhap();

        while (true)
        {
            Console.WriteLine("\n1. Tinh tong");
            Console.WriteLine("2. Tinh hieu");
            Console.WriteLine("3. Tinh tich");
            Console.WriteLine("4. Tinh thuong");
            Console.WriteLine("5. Thoat");
            Console.Write("Nhap lua chon: ");
            int luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    Console.Write("Tong: ");
                    sp1.Cong(sp2).HienThi();
                    break;
                case 2:
                    Console.Write("Hieu: ");
                    sp1.Tru(sp2).HienThi();
                    break;
                case 3:
                    Console.Write("Tich: ");
                    sp1.Nhan(sp2).HienThi();
                    break;
                case 4:
                    try
                    {
                        Console.Write("Thuong: ");
                        sp1.Chia(sp2).HienThi();
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    break;
                case 5:
                    return;
                default:
                    Console.WriteLine("Lua chon khong hop le!");
                    break;
            }
        }
    }
}