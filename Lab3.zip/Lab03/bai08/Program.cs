﻿using System;
using System.Collections.Generic;

// Lop SinhVien quan ly thong tin ca nhan
class SinhVien
{
    private string hoTen;
    private int namSinh;
    private string lop;
    private string maSoSinhVien;

    public SinhVien() { }
    public SinhVien(string hoTen, int namSinh, string lop, string maSoSinhVien)
    {
        this.hoTen = hoTen;
        this.namSinh = namSinh;
        this.lop = lop;
        this.maSoSinhVien = maSoSinhVien;
    }

    public void Nhap()
    {
        Console.Write("Nhap ho ten: ");
        hoTen = Console.ReadLine();
        Console.Write("Nhap nam sinh: ");
        namSinh = int.Parse(Console.ReadLine());
        Console.Write("Nhap lop: ");
        lop = Console.ReadLine();
        Console.Write("Nhap ma so sinh vien: ");
        maSoSinhVien = Console.ReadLine();
    }

    public void HienThi()
    {
        Console.WriteLine($"Ho ten: {hoTen}, Nam sinh: {namSinh}, Lop: {lop}, Ma so sinh vien: {maSoSinhVien}");
    }

    public string LayMaSoSinhVien()
    {
        return maSoSinhVien;
    }
}

// Lop TheMuon quan ly thong tin muon sach
class TheMuon
{
    private SinhVien thongTinSinhVien;
    private string soPhieuMuon;
    private string ngayMuon;
    private string hanTra;
    private string soHieuSach;

    public TheMuon()
    {
        thongTinSinhVien = new SinhVien();
    }

    public void Nhap()
    {
        thongTinSinhVien.Nhap();
        Console.Write("Nhap so phieu muon: ");
        soPhieuMuon = Console.ReadLine();
        Console.Write("Nhap ngay muon (dd/mm/yyyy): ");
        ngayMuon = Console.ReadLine();
        Console.Write("Nhap han tra (dd/mm/yyyy): ");
        hanTra = Console.ReadLine();
        Console.Write("Nhap so hieu sach: ");
        soHieuSach = Console.ReadLine();
    }

    public void HienThi()
    {
        thongTinSinhVien.HienThi();
        Console.WriteLine($"So phieu muon: {soPhieuMuon}, Ngay muon: {ngayMuon}, Han tra: {hanTra}, So hieu sach: {soHieuSach}");
    }

    public string LayMaSoSinhVien()
    {
        return thongTinSinhVien.LayMaSoSinhVien();
    }

    public string LayHanTra()
    {
        return hanTra;
    }
}

// Lop quan ly danh sach the muon
class QuanLyTheMuon
{
    private List<TheMuon> danhSachTheMuon = new List<TheMuon>();

    public void NhapDanhSach()
    {
        Console.Write("Nhap so luong the muon: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhap thong tin the muon thu {i + 1}:");
            TheMuon theMuon = new TheMuon();
            theMuon.Nhap();
            danhSachTheMuon.Add(theMuon);
        }
    }

    public void TimKiemTheoMaSoSinhVien()
    {
        Console.Write("Nhap ma so sinh vien can tim: ");
        string maSo = Console.ReadLine();
        bool timThay = false;

        foreach (var theMuon in danhSachTheMuon)
        {
            if (theMuon.LayMaSoSinhVien().Equals(maSo))
            {
                theMuon.HienThi();
                timThay = true;
            }
        }

        if (!timThay)
        {
            Console.WriteLine("Khong tim thay sinh vien co ma so: " + maSo);
        }
    }

    public void HienThiDenHanTra()
    {
        Console.Write("Nhap ngay hien tai (dd/mm/yyyy): ");
        string ngayHienTai = Console.ReadLine();
        bool timThay = false;

        foreach (var theMuon in danhSachTheMuon)
        {
            if (theMuon.LayHanTra().CompareTo(ngayHienTai) <= 0)
            {
                theMuon.HienThi();
                timThay = true;
            }
        }

        if (!timThay)
        {
            Console.WriteLine("Khong co sinh vien den han tra sach!");
        }
    }

    public void ChayChuongTrinh()
    {
        while (true)
        {
            Console.WriteLine("\n1. Nhap danh sach the muon");
            Console.WriteLine("2. Tim kiem theo ma so sinh vien");
            Console.WriteLine("3. Hien thi sinh vien den han tra sach");
            Console.WriteLine("4. Thoat");
            Console.Write("Nhap lua chon: ");
            int luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    NhapDanhSach();
                    break;
                case 2:
                    TimKiemTheoMaSoSinhVien();
                    break;
                case 3:
                    HienThiDenHanTra();
                    break;
                case 4:
                    return;
                default:
                    Console.WriteLine("Lua chon khong hop le!");
                    break;
            }
        }
    }
}

// Chuong trinh chinh
class Program
{
    static void Main(string[] args)
    {
        QuanLyTheMuon quanLy = new QuanLyTheMuon();
        quanLy.ChayChuongTrinh();
    }
}