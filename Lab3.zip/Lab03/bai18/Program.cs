﻿using System;
using System.Collections.Generic;

// Lop Nguoi
class Nguoi
{
    protected string hoTen;
    protected bool gioiTinh; // true: Nam, false: Nu
    protected int tuoi;

    public Nguoi() { }
    public Nguoi(string hoTen, bool gioiTinh, int tuoi)
    {
        this.hoTen = hoTen;
        this.gioiTinh = gioiTinh;
        this.tuoi = tuoi;
    }

    public virtual void Nhap()
    {
        Console.Write("Nhap ho ten: ");
        hoTen = Console.ReadLine();
        Console.Write("Nhap gioi tinh (Nam/Nu): ");
        string gt = Console.ReadLine();
        gioiTinh = gt.Equals("Nam", StringComparison.OrdinalIgnoreCase);
        Console.Write("Nhap tuoi: ");
        tuoi = int.Parse(Console.ReadLine());
    }

    public virtual void In()
    {
        Console.WriteLine($"Ho ten: {hoTen}, Gioi tinh: {(gioiTinh ? "Nam" : "Nu")}, Tuoi: {tuoi}");
    }

    public string LayHoTen() { return hoTen; }
}

// Lop CoQuan ke thua tu Nguoi
class CoQuan : Nguoi
{
    private string donViCongTac;
    private double heSoLuong;
    private double luong;
    private const double luongCoBan = 1050000;

    public CoQuan() : base() { }
    public CoQuan(string hoTen, bool gioiTinh, int tuoi, string donViCongTac, double heSoLuong)
        : base(hoTen, gioiTinh, tuoi)
    {
        this.donViCongTac = donViCongTac;
        this.heSoLuong = heSoLuong;
        TinhLuong();
    }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap don vi cong tac: ");
        donViCongTac = Console.ReadLine();
        Console.Write("Nhap he so luong: ");
        heSoLuong = double.Parse(Console.ReadLine());
        TinhLuong();
    }

    public override void In()
    {
        base.In();
        Console.WriteLine($"Don vi cong tac: {donViCongTac}, He so luong: {heSoLuong}, Luong: {luong}");
    }

    public void TinhLuong()
    {
        luong = heSoLuong * luongCoBan;
    }

    public string LayDonViCongTac() { return donViCongTac; }
}

// Lop quan ly danh sach ca nhan
class QuanLyCoQuan
{
    private List<CoQuan> danhSachCaNhan = new List<CoQuan>();

    public void NhapDanhSach()
    {
        Console.Write("Nhap so luong ca nhan: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhap thong tin ca nhan thu {i + 1}:");
            CoQuan caNhan = new CoQuan();
            caNhan.Nhap();
            danhSachCaNhan.Add(caNhan);
        }
    }

    public void HienThiPhongTaiChinh()
    {
        bool timThay = false;
        foreach (var caNhan in danhSachCaNhan)
        {
            if (caNhan.LayDonViCongTac().Equals("Phong tai chinh", StringComparison.OrdinalIgnoreCase))
            {
                caNhan.In();
                timThay = true;
            }
        }
        if (!timThay)
        {
            Console.WriteLine("Khong co ca nhan nao o Phong tai chinh!");
        }
    }

    public void TimKiemTheoHoTen()
    {
        Console.Write("Nhap ho ten can tim: ");
        string hoTen = Console.ReadLine();
        bool timThay = false;

        foreach (var caNhan in danhSachCaNhan)
        {
            if (caNhan.LayHoTen().Equals(hoTen, StringComparison.OrdinalIgnoreCase))
            {
                caNhan.In();
                timThay = true;
            }
        }
        if (!timThay)
        {
            Console.WriteLine("Khong tim thay ca nhan co ho ten: " + hoTen);
        }
    }

    public void ChayChuongTrinh()
    {
        while (true)
        {
            Console.WriteLine("\n1. Nhap danh sach ca nhan");
            Console.WriteLine("2. Hien thi ca nhan o Phong tai chinh");
            Console.WriteLine("3. Tim kiem theo ho ten");
            Console.WriteLine("4. Thoat");
            Console.Write("Nhap lua chon: ");
            int luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    NhapDanhSach();
                    break;
                case 2:
                    HienThiPhongTaiChinh();
                    break;
                case 3:
                    TimKiemTheoHoTen();
                    break;
                case 4:
                    return;
                default:
                    Console.WriteLine("Lua chon khong hop le!");
                    break;
            }
        }
    }
}

// Chuong trinh chinh
class Program
{
    static void Main(string[] args)
    {
        QuanLyCoQuan quanLy = new QuanLyCoQuan();
        quanLy.ChayChuongTrinh();
    }
}