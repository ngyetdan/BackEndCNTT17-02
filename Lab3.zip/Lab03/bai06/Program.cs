﻿using System;
using System.Collections.Generic;

// Lop Nguoi quan ly thong tin ca nhan
class Nguoi
{
    private string hoTen;
    private int tuoi;
    private int namSinh;
    private string queQuan;
    private string gioiTinh;

    public Nguoi() { }
    public Nguoi(string hoTen, int tuoi, int namSinh, string queQuan, string gioiTinh)
    {
        this.hoTen = hoTen;
        this.tuoi = tuoi;
        this.namSinh = namSinh;
        this.queQuan = queQuan;
        this.gioiTinh = gioiTinh;
    }

    public void Nhap()
    {
        Console.Write("Nhap ho ten: ");
        hoTen = Console.ReadLine();
        Console.Write("Nhap tuoi: ");
        tuoi = int.Parse(Console.ReadLine());
        Console.Write("Nhap nam sinh: ");
        namSinh = int.Parse(Console.ReadLine());
        Console.Write("Nhap que quan: ");
        queQuan = Console.ReadLine();
        Console.Write("Nhap gioi tinh: ");
        gioiTinh = Console.ReadLine();
    }

    public void HienThi()
    {
        Console.WriteLine($"Ho ten: {hoTen}, Tuoi: {tuoi}, Nam sinh: {namSinh}, Que quan: {queQuan}, Gioi tinh: {gioiTinh}");
    }

    public string LayQueQuan()
    {
        return queQuan;
    }

    public string LayGioiTinh()
    {
        return gioiTinh;
    }

    public int LayNamSinh()
    {
        return namSinh;
    }
}

// Lop HSHocSinh quan ly ho so hoc sinh
class HSHocSinh
{
    private Nguoi thongTinCaNhan;
    private string lop;
    private string khoaHoc;
    private string kyHoc;

    public HSHocSinh()
    {
        thongTinCaNhan = new Nguoi();
    }

    public void Nhap()
    {
        thongTinCaNhan.Nhap();
        Console.Write("Nhap lop: ");
        lop = Console.ReadLine();
        Console.Write("Nhap khoa hoc: ");
        khoaHoc = Console.ReadLine();
        Console.Write("Nhap ky hoc: ");
        kyHoc = Console.ReadLine();
    }

    public void HienThi()
    {
        thongTinCaNhan.HienThi();
        Console.WriteLine($"Lop: {lop}, Khoa hoc: {khoaHoc}, Ky hoc: {kyHoc}");
    }

    public string LayQueQuan()
    {
        return thongTinCaNhan.LayQueQuan();
    }

    public string LayGioiTinh()
    {
        return thongTinCaNhan.LayGioiTinh();
    }

    public int LayNamSinh()
    {
        return thongTinCaNhan.LayNamSinh();
    }
}

// Lop quan ly danh sach hoc sinh
class QuanLyHocSinh
{
    private List<HSHocSinh> danhSachHocSinh = new List<HSHocSinh>();

    public void NhapDanhSach()
    {
        Console.Write("Nhap so luong hoc sinh: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhap thong tin hoc sinh thu {i + 1}:");
            HSHocSinh hocSinh = new HSHocSinh();
            hocSinh.Nhap();
            danhSachHocSinh.Add(hocSinh);
        }
    }

    public void HienThiHocSinhNu1985()
    {
        bool timThay = false;
        foreach (var hocSinh in danhSachHocSinh)
        {
            if (hocSinh.LayGioiTinh().Equals("Nu", StringComparison.OrdinalIgnoreCase) && hocSinh.LayNamSinh() == 1985)
            {
                hocSinh.HienThi();
                timThay = true;
            }
        }

        if (!timThay)
        {
            Console.WriteLine("Khong co hoc sinh nu sinh nam 1985!");
        }
    }

    public void TimKiemTheoQueQuan()
    {
        Console.Write("Nhap que quan can tim: ");
        string queQuan = Console.ReadLine();
        bool timThay = false;

        foreach (var hocSinh in danhSachHocSinh)
        {
            if (hocSinh.LayQueQuan().Equals(queQuan, StringComparison.OrdinalIgnoreCase))
            {
                hocSinh.HienThi();
                timThay = true;
            }
        }

        if (!timThay)
        {
            Console.WriteLine("Khong tim thay hoc sinh co que quan: " + queQuan);
        }
    }

    public void ChayChuongTrinh()
    {
        while (true)
        {
            Console.WriteLine("\n1. Nhap danh sach hoc sinh");
            Console.WriteLine("2. Hien thi hoc sinh nu sinh nam 1985");
            Console.WriteLine("3. Tim kiem theo que quan");
            Console.WriteLine("4. Thoat");
            Console.Write("Nhap lua chon: ");
            int luaChon = int.Parse(Console.ReadLine());

            switch